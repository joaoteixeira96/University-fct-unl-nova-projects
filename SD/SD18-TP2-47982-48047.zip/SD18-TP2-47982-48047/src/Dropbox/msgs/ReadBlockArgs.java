package Dropbox.msgs;

public class ReadBlockArgs {

	final String path;

	public ReadBlockArgs(String path) {
		this.path = path;
	}

}
