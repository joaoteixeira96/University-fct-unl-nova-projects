package Dropbox.msgs;

public class DeleteBlockArgs {
	
	final String path;
	
	public DeleteBlockArgs(String path) {
		this.path = path;
	}

}
